package beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name ="Servico")
public class Servico {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ser_id")
	private int id;
	@Column(name = "ser_nome", length = 60, nullable = true)
	private String nome;
	@Column(name = "ser_descricao", length = 60, nullable = true)
	private String descricao;
	@Column(name = "ser_und", length = 60, nullable = true)
	private String und;
	@Column(name = "ser_valor", nullable = true)
	private float valor;
	@Column (name="ser_qtd")
	private long quantidade;
	
	@Transient
	private String caminhoFotoServico;
	
	public String getCaminho() {
		return caminhoFotoServico;
	}
	public void setCaminho(String caminho) {
		this.caminhoFotoServico = caminho;
	}
	public long getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(long quantidade) {
		this.quantidade = quantidade;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getUnd() {
		return und;
	}

	public void setUnd(String und) {
		this.und = und;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch=FetchType.EAGER, mappedBy = "servico")
	private List<Itens_Pedido> itensPedido = new ArrayList<Itens_Pedido>();

	public List<Itens_Pedido> getItensPedido() {
		return itensPedido;
	}
	public void setItensPedido(List<Itens_Pedido> itensPedido) {
		this.itensPedido = itensPedido;
	}



}	