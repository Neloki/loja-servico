package negocio;

import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import beans.Servico;
import persistencia.ServicoDAO;

@ManagedBean
@SessionScoped
public class ServicoCtrl implements Serializable {

	private static final long serialVersionUID = 1L;
	private Servico servico;
	private Servico serSelecionado;

	public List<Servico> getListagem() {
		return ServicoDAO.listagem("");
	}

	public String actionGravar() {

		if (servico.getId() == 0) {
			ServicoDAO.inserir(servico);
			return actionInserir();
		} else {
			ServicoDAO.alterar(servico);
			return "/servico/lista_servico";
		}
	}

	public String actionInserir() {
		servico = new Servico();
		return "/admin/lista_servico";
	}

	public String actionExcluir(Servico servico) {
		ServicoDAO.excluir(servico);
		return "/servico/lista_servico";
	}

	public void upload(FileUploadEvent evento) {
		try {
			UploadedFile arquivoUpload = evento.getFile();
			Path arquivoTemp = Files.createFile(null, null);
			Files.copy(arquivoUpload.getInputstream(), arquivoTemp,
					StandardCopyOption.REPLACE_EXISTING);
			servico.setCaminho(arquivoTemp.toString());
		} catch (IOException erro) {
			erro.printStackTrace();
		}
	}

	public String actionFecharDialogo() {
		servico = new Servico();

		return "/admin/lista_servico";
	}

	public Servico getServico() {
		return servico;
	}

	public void setServico(Servico servico) {
		this.servico = servico;
	}

	public Servico getSerSelecionado() {
		return serSelecionado;
	}

	public void setSerSelecionado(Servico serSelecionado) {
		this.serSelecionado = serSelecionado;
	}
}
