package negocio;

import java.io.Serializable;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;


import persistencia.ServicoDAO;
import beans.Servico;

@ManagedBean
@SessionScoped
public class ServicoCtrl implements Serializable {
	 
	private static final long serialVersionUID = 1L;
	private Servico servico = new Servico();
	private String filtro = "";
	
	public Servico getServico() {
		return servico;
	}

	public void setServico(Servico servico) {
		this.servico = servico;
	}
	
	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}
	
	public List<Servico> getListagem(){
		return ServicoDAO.listagem(filtro);
	}
	
	public void actionGravar() {
		FacesContext context = FacesContext.getCurrentInstance();
		if (servico.getId() == 0) {
			ServicoDAO.inserir(servico);
			context.addMessage(null, new FacesMessage("Sucesso",
					"Inserido com sucesso!"));
		} else {
			ServicoDAO.alterar(servico);
			context.addMessage(null, new FacesMessage("Sucesso",
					"Alterado com sucesso!"));
		}
		
	}

	public void actionInserir() {
		servico = new Servico();

	}

	public void actionExcluir() {
		ServicoDAO.excluir(servico);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, new FacesMessage("Sucesso", "Excluído com sucesso!") );
	}
}