package negocio;

import java.io.Serializable;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import beans.FormaPgto;
import beans.Itens_Pedido;
import beans.Pedido;
import beans.Pessoa;
import beans.Produto;
import persistencia.PedidoDAO;
import persistencia.PessoaDAO;

@ManagedBean
@SessionScoped
public class PedidoCtrl implements Serializable {

	private static final long serialVersionUID = 1L;

	private Pedido pedido = new Pedido();
	private Produto produto = new Produto();
	private Itens_Pedido itens = new Itens_Pedido();
	private FormaPgto formaPgto = new FormaPgto();
	private Pessoa pessoa;
	private boolean desabilitarParcelas = true;

	
	// Adiciona produtos no carrinho
	
	public String adicionarProdutoAoCarrinho(Produto p) { 	
		Itens_Pedido item = new Itens_Pedido();
		item.setPedido(pedido);
		item.setProduto(p);
		this.pedido.getItens().add(item);
		return "";
	}
	
	public Float getValorTotal() {
		Float total = 0f;
		
        if (pedido.getItens().isEmpty()){
           return total;
        }else {
        	for (int i = 0; i < pedido.getItens().size(); i++) {
        		total += (pedido.getItens().get(i).getSubTotal());
        	}
        	return total;
        }
	}
	
	
	// Adiciona um item no carrinho
	public String adicionaUm(Itens_Pedido itens){
		for(int i = 0; i < pedido.getItens().size(); i++){
			if (itens.getProduto().getNome().equals(pedido.getItens().get(i).getProduto().getNome())) {
				itens.setQuantidade(itens.getQuantidade()+1);		
			}
		}
		return "/publico/itens_pedido?faces-redirect=true";
	}
	
	
	// Remove um item do carrinho
	public String removeUm(Itens_Pedido itens){
		for(int i = 0; i < pedido.getItens().size(); i++){
			if (itens.getProduto().getNome().equals(pedido.getItens().get(i).getProduto().getNome())) {
				itens.setQuantidade(itens.getQuantidade()-1);			
			}
		}
		return "/publico/itens_pedido?faces-redirect=true";
	}
	
	public String actionPagamento() {
		return "/cliente/forma_de_pagamento?faces-redirect=true";
	}

	// Pega a data atual
	public Date dataDoSistema() { 
		Date hoje = new Date();
		return hoje;
	}

	public boolean isDesabilitarParcelas() {
		return desabilitarParcelas;
	}
	public String actionPedido() {
		ativarProduto();
		valorDoPedido();
		return "/publico/itens_pedido?faces-redirect=true";
	}
	
	public void ativarProduto() {
		float a = 0, soma =0;
		for (int i = 0; i < pedido.getItens().size(); i++) {
			a = soma + pedido.getItens().get(i).getProduto().getPreco();
			pedido.getItens().get(i).setValorUnitario(pedido.getItens().get(i).getProduto().getPreco());
			pedido.getItens().get(i).setSubTotal(pedido.getItens().get(i).getProduto().getPreco());
			pedido.getItens().get(i).setQuantidade(1);
		}
		this.itens.setSubTotal(a);
	}
	
	// Percorre a lista de produtos e soma todos os preços
	public void valorDoPedido() { 
				Itens_Pedido itens	= new Itens_Pedido();
			        float valorTotal = 0;
					for (int i = 0; i < pedido.getItens().size(); i++) {
						valorTotal += pedido.getItens().get(i).getProduto().getPreco();
					}
					this.pedido.setTotal(valorTotal);
	}
	
	public int getQtdTotal() {

        if (pedido.getItens().isEmpty()) {
        	return 0;
        }
            
        int qtdTotal = 0;

        for (int i = 0; i < pedido.getItens().size(); i++) {
            qtdTotal += (this.pedido.getItens().get(i).getQuantidade());
        }
        return qtdTotal;
    }

	// Verifica a quantidade de produtos que o cliente solicitou e o preço e calcula o subtotal
	
	public String calcQuantidadeProduto(Itens_Pedido itens) { 
		
		valorDoPedido();
		float subtotalAtualizado = 0, soma= 0;
		if (itens.getQuantidade() >= 1) {
			for (int i = 0; i < pedido.getItens().size(); i++) {
				pedido.getItens().get(i).setQuantidade(itens.getQuantidade());
				int qtd = itens.getQuantidade();
				soma = soma + (pedido.getItens().get(i).getQuantidade() * pedido.getItens().get(i).getProduto().getPreco());
				
				this.itens.setSubTotal(subtotalAtualizado + (qtd * pedido.getItens().get(i).getProduto().getPreco()));
				this.pedido.setTotal(subtotalAtualizado + (qtd * pedido.getItens().get(i).getProduto().getPreco()));
				pedido.getItens().get(i).setValorUnitario(pedido.getItens().get(i).getProduto().getPreco());
				pedido.getItens().get(i).setSubTotal(qtd * pedido.getItens().get(i).getProduto().getPreco());
			}
			System.out.println(soma);
		}
		return null;
		
		
	}
	
	
	// Exclui produtos do carrinho
	public String excluirProdutoDoCarrinho(Itens_Pedido itens) {			
		for (int i = 0; i < pedido.getItens().size(); i++) {
			if(pedido.getItens().size()==1) {
				this.itens.setSubTotal(0);
				if ( pedido.getItens().get(i).getId() == itens.getId()) {
					pedido.getItens().remove(i);
					pedido.getItens().get(i).setSubTotal(itens.getSubTotal() - itens.getProduto().getPreco());
				}
			}
			else {
			if ( pedido.getItens().get(i).getId() == itens.getId()) {
				pedido.getItens().remove(i);
				pedido.getItens().get(i).setSubTotal(itens.getSubTotal() - itens.getProduto().getPreco());
			}
			}
		}
		return null;
	}
	


	public void setDesabilitarParcelas(boolean desabilitarParcelas) {
		this.desabilitarParcelas = desabilitarParcelas;
	}

	public String definirParcelas() { // para saber se a opção de forma de pagamento é de cartão de crédito, boleto ou débito
									
		if (this.formaPgto.getId() == 6) {

			this.desabilitarParcelas = false;

		} else {
			this.desabilitarParcelas = true;
			pedido.setQtdParcelas(0);

		}
		return null;
	}
	
	public String gravarPedido() {
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			Pessoa pessoaLogada = PessoaDAO.pesqUsuarioLogado(getUsuarioLogado());
	        
			pedido.setCliente(pessoaLogada);
	        pedido.setForma_pagamento(formaPgto);
	        pedido.setDataEmissao(new Date());
	        pedido.setStatus("ABERTO");
	        pedido.setDataAutorizacao(new Date());
	        pedido.setTotal(pedido.getTotal());
	        for (int i = 0; i < pedido.getItens().size(); i++) {
	        	pedido.getItens().get(i).setPedido(pedido);
	        	pedido.getItens().get(i).setProduto(pedido.getItens().get(i).getProduto());
	        	pedido.getItens().get(i).setQuantidade(pedido.getItens().get(i).getQuantidade());
	        	pedido.getItens().get(i).setValorUnitario(pedido.getItens().get(i).getProduto().getPreco());
	        	System.out.println(pedido.getItens().get(i).getProduto().getPreco());
	        	pedido.getItens().get(i).setSubTotal(itens.getSubTotal());
	        }
	        PedidoDAO.inserir(pedido);
	        
	        
	        
		} catch (Exception e) {
			System.out.println("Erro ao salvar o pedido!"+e.getMessage());
		}
		
		pedido.getItens().clear();
		context.addMessage(null, new FacesMessage("Sucesso", "Compra realizada com sucesso"));
		return "/publico/index?faces-redirect=true";
	}
	
	 public String getUsuarioLogado() {
	        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	        return userDetails.getUsername();
	 }
	

	public FormaPgto getFormaPgto() {
		return formaPgto;
	}

	public void setFormaPgto(FormaPgto formaPgto) {
		this.formaPgto = formaPgto;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
	

	public Pedido getPedido() {
		return pedido;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}


	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Itens_Pedido getItens() {
		return itens;
	}

	public void setItens(Itens_Pedido itens) {
		this.itens = itens;
	}
	
}
